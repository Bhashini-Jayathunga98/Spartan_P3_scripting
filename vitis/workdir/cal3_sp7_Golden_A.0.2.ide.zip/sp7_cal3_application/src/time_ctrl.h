#ifndef _TIME_CTRL_H_
#define _TIME_CTRL_H_

/*******************************************************************************
 * Include Files
 ******************************************************************************/
#include <xil_io.h>

#include "xparameters.h"

/*******************************************************************************
 * Constants
 ******************************************************************************/
// AXI TIME_CTRL module base address
#define TIME_CTRL_BASE_ADDRESS XPAR_HIER_MICROBLAZE_AXI_TIME_CTRL_V1_00_A_0_BASEADDR

// AXI TIME_CTRL register offsets
#define TIME_CTRL_VERSION                   0x0000
#define TIME_CTRL_CLKS_SINCE_PPS_INT       	0x0004
#define TIME_CTRL_TIMESTAMP             	0x0008
#define TIME_CTRL_NEXT_PPS_TIMESTAMP    	0x000C
#define TIME_CTRL_GNSS_PPS_CLK_COUNT      	0x0010
#define TIME_CTRL_INT_PPS_CLK_COUNT			0x0014
#define TIME_CTRL_PPS_CLK_COUNT             0x0018
#define TIME_CTRL_STOPWATCH                 0x001C
#define TIME_CTRL_RESET                     0x0020
#define TIME_CTRL_PPS_INT_ENABLE            0x0024
#define TIME_CTRL_PPS_INT_RESYNC 	     	0x0028
#define TIME_CTRL_STATUS                    0x002C

#define TIME_CTRL_STATUS_DCM_LOCKED_BIT     0x1

#define TIME_CTRL_ID 	0xBACD

// AXI DAC7611_CTRL module base address
//#define DAC7611_BASE_ADDRESS XPAR_NGSS_AXI_DAC7611_V1_00_A_0_BASEADDR

#define DAC82002_BASE_ADDRESS XPAR_HIER_MICROBLAZE_AXIL_DAC82002_0_S00_AXI_BASEADDR

// AXI DAC7611_CTRL register offsets
#define DAC7611_WRITE_DATA        	0x0000
#define DAC7611_IS_IDLE            	0x0004

// AXI DAC82002_CTRL register offsets
#define DAC82002_WRITE_DATA 0x0000
#define DAC82002_STATUS     0x0004

/*******************************************************************************
 * Macros
 ******************************************************************************/
#define timeCtrl_axiWrite(regOffset, data) \
	Xil_Out32((TIME_CTRL_BASE_ADDRESS) + (regOffset), (u32)data)

#define timeCtrl_axiRead(regOffset) \
	Xil_In32((TIME_CTRL_BASE_ADDRESS) + (regOffset))

#define TIMECTRL_READ_ID() \
	(timeCtrl_axiRead(TIME_CTRL_VERSION) >> 16)

#define TIMECTRL_READ_VERSION() \
	(timeCtrl_axiRead(TIME_CTRL_VERSION) & 0xFFFF)

#define TIMECTRL_READ_STOPWATCH() \
	timeCtrl_axiRead(TIME_CTRL_STOPWATCH)

#define TIMECTRL_RESET_STOPWATCH() \
	timeCtrl_axiWrite(TIME_CTRL_STOPWATCH, 0)

#define TIMECTRL_TIMESTAMP() \
	timeCtrl_axiRead(TIME_CTRL_TIMESTAMP)

#define TIMECTRL_STATUS() \
	timeCtrl_axiRead(TIME_CTRL_STATUS)

#define TIMECTRL_CLKS_SINCE_PPS() \
	timeCtrl_axiRead(TIME_CTRL_CLKS_SINCE_PPS_INT)

#define TIMECTRL_SET_NEXT_PPS_TIMESTAMP(timestamp) \
	timeCtrl_axiWrite(TIME_CTRL_NEXT_PPS_TIMESTAMP, timestamp)

#define TIMECTRL_PPS_INT_RESYNC() \
	timeCtrl_axiWrite(TIME_CTRL_PPS_INT_RESYNC, 0)

#define TIMECTRL_RESET(reg) \
	timeCtrl_axiWrite(TIME_CTRL_RESET, reg)

#define TIMECTRL_SET_PPS_INT_ENABLE(reg) \
	timeCtrl_axiWrite(TIME_CTRL_PPS_INT_ENABLE, reg)

#define TIMECTRL_GET_PPS_INT_ENABLE() \
	timeCtrl_axiRead(TIME_CTRL_PPS_INT_ENABLE)

#define dac82002_axiWrite(regOffset, data) \
	Xil_Out32((DAC82002_BASE_ADDRESS) + (regOffset), (u32)data)

#define dac82002_axiRead(regOffset) \
	Xil_In32((DAC82002_BASE_ADDRESS) + (regOffset))


/*******************************************************************************
 * Function Prototypes
 ******************************************************************************/
int timeCtrl_init();
void timeCtrl_sendTimestamp();
void timeCtrl_tcxoAutoTuneUpdate();
void timeCtrl_setTime(u32 timestamp);

#endif // _TIME_CTRL_H_
