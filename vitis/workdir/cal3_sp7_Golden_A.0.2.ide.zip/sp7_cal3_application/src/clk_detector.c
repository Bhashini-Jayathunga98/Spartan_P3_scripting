#include <xil_printf.h>
#include <stdbool.h>
#include <string.h>
#include "xstatus.h"
#include "xuartns550.h"
#include "xuartns550_l.h"
#include "xgpio_l.h"
#include "sp7_hw.h"
#include "sleep.h"
#include "xparameters.h"
#include "clk_detector.h"

int clk_detector_init() {

	xil_printf("\n\rClock Detector Initializing... ");
	usleep(2000000);
	XGpio_WriteReg(CLK_DETECTOR_RUN_ADDR, START_SIG_OFFSET, START_SIG_VAL);
	usleep(3000000);
	s32 clk_sel = XGpio_ReadReg(CLOCK_SELECT_ADDR,CLOCK_SELECT_SIG_OFFSET);
	usleep(50000);
	xil_printf("Done! \n\r");

	return clk_sel;

}

/*
int clk_detector_init() {

	xil_printf("\n\rClock Detector Initializing... ");

	XGpio_WriteReg(CLK_DETECTOR_RUN_ADDR, START_SIG_OFFSET, START_SIG_VAL);
	usleep(2000000);
	s32 clk_sel = XGpio_ReadReg(CLOCK_SELECT_ADDR,CLOCK_SELECT_SIG_OFFSET);
	usleep(50000);
	xil_printf("Done! \n\r");

	return clk_sel;
}

*/
