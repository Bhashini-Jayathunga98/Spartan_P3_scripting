/***************************************************************************//**
 * \file    gnss.c
 *
 * This file handles the interface with the u-blox GNSS receiver.
 *
 * It supports reception of the UBX-TIM-TP message only from the GNSS.
 *
 * The GNSS UART data is received using polling. This makes the execution time
 * very deterministic. The AXI UART FIFO is guaranted not to overflow as it has
 * been extended to hold up to 32 characters - the GNSS receiver transmits
 * only one UBX-TIM-TP message (24 characters) every second.
 *
 * \note The current implementation does not support configuration of
 * the GNSS receiver i.e it is assumed that the GNSS receiver
 * is configured externally.
 *
 * \author  Nicolas Barthelemy <nbarthelemy@widenorth>
 * \date    4 march 2022
 ******************************************************************************/

/*******************************************************************************
 * Include Files
 ******************************************************************************/
#include "gnss.h"

#include "string.h"
#include "xil_printf.h"
#include "xstatus.h"
#include "xuartns550.h"
#include "xuartns550_l.h"

#include "sp7_hw.h"
#include "time_ctrl.h"
#include "ubx_message.h"
#include "u_error_common.h"
#include "u_ubx_protocol.h"

/*******************************************************************************
 * Constants
 ******************************************************************************/

// Received buffer length in bytes
#define UART_BUFFER_LEN 		64

// UBX message length in bytes
// Support only UBX-TIM-TP message so limit the message length buffer
// to the UBX-TIM-TP message length
#define UBX_DATA_LEN 			sizeof(ubxTimTpMessage_t)

/*******************************************************************************
 * Types
 ******************************************************************************/

/*******************************************************************************
 * Macros
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
static XUartNs550 UartNs550;		/* The instance of the UART Driver */
static char RecvBuffer[UART_BUFFER_LEN];
static char messageData[UBX_DATA_LEN];
static u32 bufferPos;

/*******************************************************************************
 * Function Prototypes
 ******************************************************************************/
static int gnss_processUbxTimTPMessage(char *pMessage, size_t messageLength);
static int gnss_processUbxMessage(const int32_t messageClass, const int32_t messageId, char *pMessage, size_t messageLength);
static void gnss_uartRead();


// Initialize the gnss module and GNSS AXI UART driver
int gnss_init() {

	XStatus status;

    // Initialize static variables
	bufferPos = 0;


	// Initialize the UartNs550 device so that it is ready to use
    XUartNs550_Config * ConfigPtr = XUartNs550_LookupConfig(GNSS_UART_DEVICE_ID);
	if (ConfigPtr == (XUartNs550_Config *)NULL) {
		xil_printf("Error : XST Device not found\n\r");
		return XST_DEVICE_NOT_FOUND;
	}
	else {
		xil_printf("Initialized the UartNs550... \n\r");
	}

	ConfigPtr->BaseAddress = XPAR_HIER_MICROBLAZE_AXI_UART16550_V1_02_A_0_BASEADDR;

	// Set baudrate
	ConfigPtr->DefaultBaudRate = GNSS_UART_BAUD_RATE;
	status = XUartNs550_CfgInitialize(&UartNs550, ConfigPtr, ConfigPtr->BaseAddress);

	// TODO: configure GNSS receiver

	//XUartNs550_SelfTest(&UartNs550);

    return status;
}

// Process UBX-TIM-TP message providing timing information of the next PPS pulse
static int gnss_processUbxTimTPMessage(char *pMessage, size_t messageLength) {

    if (messageLength != sizeof(ubxTimTpMessage_t)) {
        xil_printf("Error: Invalid UBX-TIM-TP message length (%d)\n\r", messageLength);
        return XST_FAILURE;
    }

    // Parse message
    ubxTimTpMessage_t ubxTimTpMessage;
    memcpy(&ubxTimTpMessage, pMessage, sizeof(ubxTimTpMessage_t));

    // Convert time pulse data to 32-bit unsigned integer in second
    u32 nextPpsTime = ubxTimTpMessage.towMS / 1000 + (u32)ubxTimTpMessage.week * 3600 * 24 * 7;
    //xil_printf("(%d) New UBX times received %d\n\r", TIMECTRL_CLKS_SINCE_PPS(), nextPps);

    /*
    xil_printf("New UBX-TIM-TP towMS=%d, towSubMS=%d, qErr=%d, week=%d, timeBase=%d, utc=%d, raim=%d, qErrInvalid=%d, timeRefGnss=%d, utcStandard=%d\n\r",
        ubxTimTpMessage.towMS, ubxTimTpMessage.towSubMS, ubxTimTpMessage.qErr, ubxTimTpMessage.week,
        ubxTimTpMessage.timeBase, ubxTimTpMessage.utc, ubxTimTpMessage.raim, ubxTimTpMessage.qErrInvalid, ubxTimTpMessage.timeRefGnss, ubxTimTpMessage.utcStandard);
	*/

    // Set/monitor time
    timeCtrl_setTime(nextPpsTime);

    return XST_SUCCESS;
}

// Process a UBX message
static int gnss_processUbxMessage(const int32_t messageClass, const int32_t messageId, char *pMessage, size_t messageLength) {

    int ret;

    switch(messageClass) {
    case UBX_CLASS_TIM:
        switch(messageId) {
        case UBX_TIM_TP:
                // Time pulse time data
                ret = gnss_processUbxTimTPMessage(pMessage, messageLength);
                break;
		default:
			// Unsupported message Id
			xil_printf("Unsupported UBX-TIM message id %d\n\r", messageId);
			return XST_FAILURE;
        }
        break;
	default:
		// Unsupported message class
		xil_printf("Unsupported UBX message class %d\n\r", messageClass);
		return XST_FAILURE;
    }

    return ret;
}

// Read characters from GNSS UART into the received buffer
static void gnss_uartRead() {

	size_t s = UART_BUFFER_LEN - UBX_TIM_TP_FRAME_LEN;

	if (bufferPos > s) {
		xil_printf("buffer overflow. reset buffer\n\r");
		bufferPos = 0;
	}

	u32 nbytes = XUartNs550_Recv(&UartNs550, (u8*)(RecvBuffer + bufferPos), UBX_TIM_TP_FRAME_LEN);
	bufferPos += nbytes;

}

// Read data from GNSS UART and decode the received data
void gnss_uartProcess() {

    int32_t messageClass;
    int32_t messageId;




    // Read UART
    gnss_uartRead();

    // Do not try to decode if the received buffer does not contain
    // at least a full UBX-TIM-TP frame
    if (bufferPos < UBX_TIM_TP_FRAME_LEN) {
    	//xil_printf("buffer does not contain at least a full UBX-TIM-TP frame\n\r");
    	return;
    }

    // Decode UBX data
    int status = uUbxProtocolDecode(RecvBuffer, bufferPos, &messageClass, &messageId,
                    messageData, UBX_DATA_LEN, NULL);

    if (status > 0) {

        // Decode UBX message
        gnss_processUbxMessage(messageClass, messageId, messageData, status);

        // Discard all data in the received buffer
        bufferPos = 0;
        xil_printf("Decoding UBX message...\n\r");
    }

}
