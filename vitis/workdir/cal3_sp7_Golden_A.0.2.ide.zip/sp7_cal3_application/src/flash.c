#include "xparameters.h"
#include "xintc.h"
#include "xspi.h"
#include "xil_exception.h"
#include "xil_printf.h"
#include "flash_upgrade.h"

#define SPI_DEVICE_ID			XPAR_SPI_0_DEVICE_ID
#define INTC_DEVICE_ID			XPAR_INTC_0_DEVICE_ID
#define SPI_INTR_ID			XPAR_INTC_0_DEVICE_ID

#define INTEL_SPI_SELECT 0x01

#define INTEL_COMMAND_RANDOM_READ	0x03 /* Random read command */
#define INTEL_COMMAND_RANDOM_READ_4_BYTE_MODE	0x13 /* Random read command 4 BYTE MODE*/
#define INTEL_COMMAND_PAGEPROGRAM_WRITE	0x02 /* Page Program command */
#define INTEL_COMMAND_PAGEPROGRAM_WRITE_4BYTE	0x12 /* Page Program command 4 Byte Address */
#define	INTEL_COMMAND_WRITE_ENABLE	0x06 /* Write Enable command */
#define INTEL_COMMAND_SECTOR_ERASE	0xD8 /* Sector Erase command */
#define INTEL_COMMAND_SECTOR_ERASE_4_BYTE_MODE	0xDC
#define INTEL_COMMAND_BULK_ERASE	0xC7 /* Bulk Erase command */
#define INTEL_COMMAND_STATUSREG_READ	0x05 /* Status read command */
#define INTEL_COMMAND_STATUSREG_WRITE	0x01 /* Status write command */

#define INTEL_READ_WRITE_EXTRA_BYTES	5 /* Read/Write extra bytes */
#define	INTEL_WRITE_ENABLE_BYTES	1 /* Write Enable bytes */
#define INTEL_SECTOR_ERASE_BYTES	4 /* Sector erase extra bytes */
#define INTEL_SECTOR_ERASE_BYTES_4_BYTE_MODE	5
#define INTEL_BULK_ERASE_BYTES		1 /* Bulk erase extra bytes */
#define INTEL_STATUS_READ_BYTES		2 /* Status read bytes count */
#define INTEL_STATUS_WRITE_BYTES	2 /* Status write bytes count */

#define INTEL_FLASH_SR_IS_READY_MASK	0x01 /* Ready mask */
#define INTEL_DISABLE_PROTECTION_ALL	0x00

#define INTEL_FLASH_PAGE_SIZE		256

#define BYTE1			0 /* Byte 1 position */
#define BYTE2			1 /* Byte 2 position */
#define BYTE3			2 /* Byte 3 position */
#define BYTE4			3 /* Byte 4 position */
#define BYTE5			4 /* Byte 5 position */

static int SpiIntelFlashWriteEnable(XSpi *SpiPtr);
static int SpiIntelFlashSectorErase(XSpi *SpiPtr, u32 Addr);
static int SpiIntelFlashGetStatus(XSpi *SpiPtr);
static int SpiIntelFlashWriteStatus(XSpi *SpiPtr, u8 StatusRegister);
static int SpiIntelFlashWaitForFlashNotBusy(void);
static void SpiHandler(void *CallBackRef, u32 StatusEvent, unsigned int ByteCount);
static int SetupInterruptSystem(XSpi *SpiPtr);

static XIntc InterruptController;
static XSpi Spi;

volatile static int TransferInProgress;
int ErrorCount;

u8 ReadBuffer[INTEL_FLASH_PAGE_SIZE + INTEL_READ_WRITE_EXTRA_BYTES];
u8 WriteBuffer[INTEL_FLASH_PAGE_SIZE + INTEL_READ_WRITE_EXTRA_BYTES];

/*****************************************************************************/
/**
*
**
******************************************************************************/
int SpiInitialize() {
	int Status;
	XSpi_Config *ConfigPtr;

	xil_printf("Initialize SPI\n\r");

	ConfigPtr = XSpi_LookupConfig(SPI_DEVICE_ID);
	if (ConfigPtr == NULL) {
		return XST_DEVICE_NOT_FOUND;
	}

	Status = XSpi_CfgInitialize(&Spi, ConfigPtr,
				  ConfigPtr->BaseAddress);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = SetupInterruptSystem(&Spi);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	XSpi_SetStatusHandler(&Spi, &Spi, (XSpi_StatusHandler)SpiHandler);

	Status = XSpi_SetOptions(&Spi, XSP_MASTER_OPTION |
						XSP_MANUAL_SSELECT_OPTION);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XSpi_SetSlaveSelect(&Spi, INTEL_SPI_SELECT);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	XSpi_Start(&Spi);

	Status = SpiIntelFlashWriteEnable(&Spi);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = SpiIntelFlashWaitForFlashNotBusy();
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = SpiIntelFlashWriteStatus(&Spi, INTEL_DISABLE_PROTECTION_ALL);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
**
******************************************************************************/
int SpiFlashRead(u32 Addr,  u8 *data, u32 ByteCount) {
	int Status;

	//xil_printf("Read data from flash, addr 0x%X, count %d\n\r", Addr, ByteCount);

	Status = SpiIntelFlashWaitForFlashNotBusy();
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	WriteBuffer[BYTE1] = INTEL_COMMAND_RANDOM_READ_4_BYTE_MODE;
	WriteBuffer[BYTE2] = (u8) (Addr >> 24);
	WriteBuffer[BYTE3] = (u8) (Addr >> 16);
	WriteBuffer[BYTE4] = (u8) (Addr >> 8);
	WriteBuffer[BYTE5] = (u8) Addr;

	TransferInProgress = TRUE;
	Status = XSpi_Transfer(&Spi, WriteBuffer, ReadBuffer,
				(ByteCount + INTEL_READ_WRITE_EXTRA_BYTES));
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	while(TransferInProgress);
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	memcpy(data, (ReadBuffer+INTEL_READ_WRITE_EXTRA_BYTES), ByteCount);

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
**
******************************************************************************/
int SpiFlashErase(u32 Addr, u32 ByteCount) {
	int Status;
	//int SectorNmbr = 0;
	u32 EraseAddr;

//	xil_printf("Flash erase, addr 0x%X, count %d\n\r", Addr, ByteCount);

	Status = SpiIntelFlashWaitForFlashNotBusy();
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	EraseAddr = Addr;
	while(1) {
		Status = SpiIntelFlashWriteEnable(&Spi);
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		Status = SpiIntelFlashWaitForFlashNotBusy();
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		//xil_printf("Erase sector %d addr = 0x%X\n\r", SectorNmbr++, EraseAddr);
		Status = SpiIntelFlashSectorErase(&Spi, EraseAddr);
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		Status = SpiIntelFlashWaitForFlashNotBusy();
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}
#if TEST_ON_EVM
		if (EraseAddr < (SECTOR_CNT_64KB * SECTOR_SIZE_64KB)) {
			EraseAddr = EraseAddr + SECTOR_SIZE_64KB;
		} else {
			EraseAddr = EraseAddr + SECTOR_SIZE_4KB;
		}
#else
		if ((EraseAddr + SECTOR_SIZE_64KB) < (Addr + ByteCount)) {
			EraseAddr = EraseAddr + SECTOR_SIZE_64KB;
		} else {
			EraseAddr = EraseAddr + SECTOR_SIZE_4KB;
		}
#endif
		if (EraseAddr > (Addr + ByteCount)) {
			xil_printf("Erase done. End address is 0x%X\n\r", EraseAddr);
			break;
		}
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
**
******************************************************************************/
int SpiFlashWrite(u32 Addr, u8 *data, u32 ByteCount) {
	int Status;
	u32 Index;
	u32 ByteCntForTransfer;
	u32 SentBytes;
	u32 WriteAddr;

	//xil_printf("Write data to flash, addr 0x%X, count %d\n\r", Addr, ByteCount);

	SentBytes = 0;
	ByteCntForTransfer = FLASH_PAGE_SIZE;
	WriteAddr = Addr;

	while (SentBytes < ByteCount) {
		if ((ByteCount - SentBytes) >= FLASH_PAGE_SIZE) {
			ByteCntForTransfer = FLASH_PAGE_SIZE;
		} else {
			ByteCntForTransfer = ByteCount - SentBytes;
		}
//		xil_printf("ByteCntForTransfer  %d\n\r", ByteCntForTransfer);

		Status = SpiIntelFlashWaitForFlashNotBusy();
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		Status = SpiIntelFlashWriteEnable(&Spi);
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		Status = SpiIntelFlashWaitForFlashNotBusy();
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		WriteBuffer[BYTE1] = INTEL_COMMAND_PAGEPROGRAM_WRITE_4BYTE;
		WriteBuffer[BYTE2] = (u8) (WriteAddr >> 24);
		WriteBuffer[BYTE3] = (u8) (WriteAddr >> 16);
		WriteBuffer[BYTE4] = (u8) (WriteAddr >> 8);
		WriteBuffer[BYTE5] = (u8) WriteAddr;

		for(Index = INTEL_READ_WRITE_EXTRA_BYTES; Index < ByteCntForTransfer + INTEL_READ_WRITE_EXTRA_BYTES;
							Index++) {
			WriteBuffer[Index] = *data;
			data++;
		}

		TransferInProgress = TRUE;
		Status = XSpi_Transfer(&Spi, WriteBuffer, NULL,
					(ByteCntForTransfer + INTEL_READ_WRITE_EXTRA_BYTES));
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		SentBytes = SentBytes + ByteCntForTransfer;
//		xil_printf("SentBytes  %d\n\r", SentBytes);
		WriteAddr = WriteAddr + FLASH_PAGE_SIZE;

		while(TransferInProgress);
		if(ErrorCount != 0) {
			xil_printf("Error occurred during transfer, Error count %d\n\r",ErrorCount);
			ErrorCount = 0;
			return XST_FAILURE;
		}
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function enables writes to the Intel Serial Flash memory.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		None.
*
******************************************************************************/
static int SpiIntelFlashWriteEnable(XSpi *SpiPtr)
{
	int Status;

	/*
	 * Prepare the WriteBuffer.
	 */
	WriteBuffer[BYTE1] = INTEL_COMMAND_WRITE_ENABLE;

	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL,
				INTEL_WRITE_ENABLE_BYTES);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction..
	 */
	while(TransferInProgress);
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function erases the contents of the specified Sector in the Intel Serial
* Flash.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
* @param	Addr is the address within a sector of the Buffer, which is to
*		be erased.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		The erased bytes will read as 0xFF.
*
******************************************************************************/
static int SpiIntelFlashSectorErase(XSpi *SpiPtr, u32 Addr)
{
	int Status;

	/*
	 * Prepare the WriteBuffer.
	 */
	WriteBuffer[BYTE1] = INTEL_COMMAND_SECTOR_ERASE_4_BYTE_MODE;
	WriteBuffer[BYTE2] = (u8) (Addr >> 24);
	WriteBuffer[BYTE3] = (u8) (Addr >> 16);
	WriteBuffer[BYTE4] = (u8) (Addr >> 8);
	WriteBuffer[BYTE5] = (u8) (Addr);

	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL,
			INTEL_SECTOR_ERASE_BYTES_4_BYTE_MODE);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction.
	 */
	while(TransferInProgress);
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function reads the Status register of the Intel Serial Flash.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		The status register content is stored at the second byte pointed
*		by the ReadBuffer.
*
******************************************************************************/
static int SpiIntelFlashGetStatus(XSpi *SpiPtr)
{
	int Status;

	/*
	 * Prepare the Write Buffer.
	 */
	WriteBuffer[BYTE1] = INTEL_COMMAND_STATUSREG_READ;

	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, ReadBuffer,
						INTEL_STATUS_READ_BYTES);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction.
	 */
	while(TransferInProgress);
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function writes to the Status register of the Intel Flash.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
* @param	StatusRegister is the value to be written to the status register
* 		of the flash device.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		The status register content is stored at the second byte pointed
*		by the ReadPtr.
*
******************************************************************************/
static int SpiIntelFlashWriteStatus(XSpi *SpiPtr, u8 StatusRegister)
{
	int Status;

	/*
	 * Prepare the Write Buffer.
	 */
	WriteBuffer[BYTE1] = INTEL_COMMAND_STATUSREG_WRITE;
	WriteBuffer[BYTE2] = StatusRegister;

	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL,
				INTEL_STATUS_WRITE_BYTES);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction..
	 */
	while(TransferInProgress);
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function waits till the Intel Serial Flash is ready to accept next
* command.
*
* @param	None
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		This function reads the status register of the Buffer and waits
*.		till the WIP bit of the status register becomes 0.
*
******************************************************************************/
static int SpiIntelFlashWaitForFlashNotBusy(void)
{
	int Status;
	u8 StatusReg;

	while(1) {

		/*
		 * Get the Status Register.
		 */
		Status = SpiIntelFlashGetStatus(&Spi);
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		/*
		 * Check if the flash is ready to accept the next command.
		 * If so break.
		 */
		StatusReg = ReadBuffer[1];
		if((StatusReg & INTEL_FLASH_SR_IS_READY_MASK) == 0) {
			break;
		}
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function is the handler which performs processing for the SPI driver.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized. It is called when a transfer of SPI data
* completes or an error occurs.
*
* This handler provides an example of how to handle SPI interrupts and
* is application specific.
*
* @param	CallBackRef is the upper layer callback reference passed back
*		when the callback function is invoked.
* @param	StatusEvent is the event that just occurred.
* @param	ByteCount is the number of bytes transferred up until the event
*		occurred.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
static void SpiHandler(void *CallBackRef, u32 StatusEvent, unsigned int ByteCount)
{
	/*
	 * Indicate the transfer on the SPI bus is no longer in progress
	 * regardless of the status event.
	 */
	TransferInProgress = FALSE;

	/*
	 * If the event was not transfer done, then track it as an error.
	 */
	if (StatusEvent != XST_SPI_TRANSFER_DONE) {
		ErrorCount++;
	}
}

/*****************************************************************************/
/**
*
* This function setups the interrupt system such that interrupts can occur
* for the Spi device. This function is application specific since the actual
* system may or may not have an interrupt controller. The Spi device could be
* directly connected to a processor without an interrupt controller.  The
* user should modify this function to fit the application.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
*
* @return	XST_SUCCESS if successful, otherwise XST_FAILURE.
*
* @note		None
*
******************************************************************************/
static int SetupInterruptSystem(XSpi *SpiPtr)
{

	int Status;

	/*
	 * Initialize the interrupt controller driver so that
	 * it's ready to use, specify the device ID that is generated in
	 * xparameters.h
	 */
	Status = XIntc_Initialize(&InterruptController, INTC_DEVICE_ID);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Connect a device driver handler that will be called when an interrupt
	 * for the device occurs, the device driver handler performs the
	 * specific interrupt processing for the device
	 */
	Status = XIntc_Connect(&InterruptController,
				SPI_INTR_ID,
				(XInterruptHandler)XSpi_InterruptHandler,
				(void *)SpiPtr);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Start the interrupt controller such that interrupts are enabled for
	 * all devices that cause interrupts, specific real mode so that
	 * the SPI can cause interrupts through the interrupt controller.
	 */
	Status = XIntc_Start(&InterruptController, XIN_REAL_MODE);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Enable the interrupt for the SPI.
	 */
	XIntc_Enable(&InterruptController, SPI_INTR_ID);


	/*
	 * Initialize the exception table
	 */
	Xil_ExceptionInit();

	/*
	 * Register the interrupt controller handler with the exception table
	 */
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
			 (Xil_ExceptionHandler)XIntc_InterruptHandler,
			 &InterruptController);

	/*
	 * Enable non-critical exceptions
	 */
	Xil_ExceptionEnable();

	return XST_SUCCESS;
}


