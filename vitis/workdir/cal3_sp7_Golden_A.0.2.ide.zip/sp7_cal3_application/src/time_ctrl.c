/*******************************************************************************
 * MADUSHAN S.D. - THAKSHANA TECHNOLOGIES
 ******************************************************************************/

/***************************************************************************//**
 * \file    time_ctrl.c
 *
 * This file contains functionality related to PPS and TCXO/OCXO tuning.
 *
 * \author  Nicolas Barthelemy <nbarthelemy@widenorth>
 * \date    4 march 2022
 ******************************************************************************/

/*******************************************************************************
 * Include Files
 ******************************************************************************/
#include "time_ctrl.h"

#include <stdbool.h>
#include <string.h>
#include "xstatus.h"
#include "xuartns550_l.h"

#include "ubx_message.h"
#include "u_ubx_protocol.h"
#include "sleep.h"
#include "sp7_hw.h"

/*******************************************************************************
 * Constants
 ******************************************************************************/
#define TCXO_100MHz_FREQUENCY_CLKS 	100000000
#define CLK_50MHz_FREQUENCY_CLKS  	50000000

// Time error sanity check
// When locking the time error can be relatively consequent
// It can be considered having a narrower window when the DPLL is locked
#define TIME_ERROR_MAX	10000

// TCXO locked flag
#define TCXO_LOCKED_UPDATE_RATE 10 		// Update TCXO lock flag every 10 sec
#define TCXO_LOCKED_MAX_ERROR 	20		// Allow maximum of 1 clock cycles (10ns) time error per second over the observation window


// DAC82002 init voltage value
//#define DAC82002_DEFAULT 	0xD9A9			// in mV. 2.525v
#define DAC82002_DEFAULT 	 0x7650			// in mV. 2.525v
#define DAC82002_SMOOTH_LOW  0x7600
#define DAC82002_SMOOTH_HIGH 0x76A0

// DAC82002 output value allowed range
#define DAC82002_MIN 		0x0000		// in mV
#define DAC82002_MAX 		0xFFFF		// in mV (65536)

// Comment out to send the UBX-DIG14-TIME frame as ASCII data on the UART
// By default it is transmitted in binary format
#define UBX_DIG14_TIME_IN_ASCCI_FORMAT

/*******************************************************************************
 * Types
 ******************************************************************************/

/*******************************************************************************
 * Macros
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
static bool lastTimeMessageSent;
static bool isTimeSet;
static bool errtooPos;
static bool errtooNeg;
static u32 tcxoLockCounterSec;
static s32 tcxoLockError;
static u32 gnssClkLast;
static u32 gnssClkMeas;
static u32 intClkMeas;
static s32 intPpsError;
static u32 clkCount;
static u32 gnssClkExp;
static s32 timeError;
static s32 timeError_i;
static s32 error;
static s32 newDacValue;
static s32 tunedDacvalue;

static float timeError_propotional;
static float timeError_integral;
static float timeError_pi;
static int dcmErr_cnt;

static ubxDig14TimeMessage_t message;
static char messageData[sizeof(ubxDig14TimeMessage_t)];
static char txBuffer[UBX_DIG14_TIME_FRAME_LEN];

// IIR filter coefficients
static const float a[3] = {1.0f, -1.6f, 0.6f};
static const float b[3] = {0.673910f, 0.032873f, -0.641036};

// IIR filter states
static float in[3];
static float out[3];

/*******************************************************************************
 * Function Prototypes
 ******************************************************************************/
//static int dac7611_write(s32 reg, bool force_update);
static int dac82002_write(s32 value);
static float filter_iir(float in_new);

// Initialize the TIME_CTRL module.
int timeCtrl_init() {

	// Initialize static variables
	dcmErr_cnt = 0;

	lastTimeMessageSent = false;
	isTimeSet = false;
	tcxoLockCounterSec = 0;
	tcxoLockError = 0;
	gnssClkLast = 0;
	timeError_integral =0;
	timeError_propotional=0;
	timeError_pi=0;
	tunedDacvalue = DAC82002_DEFAULT;

	message.timeInvalid = true;
	message.ppsInvalid = true;
	message.gnssPpsMissing = true;
	message.lastGnssPpsInvalid = false;

	// Initialize IIR filter states
	u8 i;
	for (i = 0; i < 3; i++) {
		in[i] = 0;
		out[i] = (float)DAC82002_DEFAULT;
	}

	// Sanity check
	u16 id = TIMECTRL_READ_ID();
	if (id != TIME_CTRL_ID) {
		xil_printf("Error: invalid id (%d)\n\r", id);
		return XST_FAILURE;
	}

	// Report IP version
	xil_printf("Using AXI_TIME_CTRL IP version %d\n\r", TIMECTRL_READ_VERSION());

	// Verify that DCM is locked. Halt operation if not?
	u32 timeCtrlStatus = TIMECTRL_STATUS();
	//xil_printf("10M locked status: %d\n\r",timeCtrlStatus);
	if (!(timeCtrlStatus & TIME_CTRL_STATUS_DCM_LOCKED_BIT)) {
		xil_printf("Warning: DCM not locked\n\r");
	}


	// Set DAC value to default
	//xil_printf("Writing default DAC value...\n\r");
	//int status = dac7611_write(DAC7611_DEFAULT, true);
	int status = dac82002_write(DAC82002_DEFAULT);

	// Release reset
	// The first GNSS PPS pulse is assumed to be valid
	TIMECTRL_RESET(0);

	// Enable internal PPS enable
	// Note: it could be enabled only when the DPLL is locked
	// This is not done here (the internal PPS output is always enabled)
	TIMECTRL_SET_PPS_INT_ENABLE(1);

    return status;
}

// Performs TCXO auto-tuning.
// This function is run once per second (after each received GNSS pulse).
void timeCtrl_tcxoAutoTuneUpdate() {

	// Verify that DCM is locked. Halt operation if not?
		u32 timeCtrlStatus = TIMECTRL_STATUS();

		if (!(timeCtrlStatus & TIME_CTRL_STATUS_DCM_LOCKED_BIT)) {
			xil_printf("\n\rWarning: DCM not locked\n\r");
			dcmErr_cnt = dcmErr_cnt+1;
			if (dcmErr_cnt>10)
			{
				dcmErr_cnt=0;
				return;
			}

		}

	// Read free-running counter value  latched on last GNSS PPS pulse
	gnssClkMeas = timeCtrl_axiRead(TIME_CTRL_GNSS_PPS_CLK_COUNT);
	usleep(5);
	//xil_printf("TIME_CTRL_GNSS_PPS_CLK_COUNT is %d\n\r",gnssClkMeas);

	// If we read a null value, a new value is not ready yet
	if (gnssClkMeas == 0) {
		// Check if we have missed a GNSS PPS pulse
		if (gnssClkLast != 0) {
			timeCtrl_axiWrite(TIME_CTRL_PPS_CLK_COUNT, 0); //latching

			clkCount = timeCtrl_axiRead(TIME_CTRL_PPS_CLK_COUNT); //clock cycles since last reset

			error = (s32)clkCount - (s32)gnssClkLast;

			// If the clock counter is more than 1.10second ahead of the last GNSS PPS
			// we have not received one GNSS PPS. Move the last GNSS PPS by 1 second
			if (error > (TCXO_100MHz_FREQUENCY_CLKS + 10000000)) {
				xil_printf("\n\rMissing GNSS PPS detected (clkCount=%d, gnssClkLast=%d, error=%d)\r\n", clkCount, gnssClkLast, error);
				gnssClkLast += TCXO_100MHz_FREQUENCY_CLKS;
				message.gnssPpsMissing = true;
			}


		}
		return;
	}
	else{
		xil_printf("\n\rPPS DETECTED.. GNSS_PPS_CLK_COUNT is %d\n\r",gnssClkMeas);
	}

	xil_printf("10M locked status: %d\n\r",timeCtrlStatus); //just for debug

	// Clear register for next read
	timeCtrl_axiWrite(TIME_CTRL_GNSS_PPS_CLK_COUNT, 0);
	usleep(5);

	// Is it the first received GNSS PPS?
	if (gnssClkLast == 0) {
		gnssClkLast = gnssClkMeas;
		return;
	}

	// Phase detector
	// Measure the time error (phase error) between the expected clock count value
	// and the measured clock count when the GNSS PPS is received
	gnssClkExp = gnssClkLast + TCXO_100MHz_FREQUENCY_CLKS;
	timeError = (s32)gnssClkExp - (s32)gnssClkMeas;
	//xil_printf("Current gnss clock count is %d\n\r",gnssClkMeas);
	xil_printf("Expected gnss clock count is %d\n\r",gnssClkExp);
	xil_printf("Time error (phase error) between the expected clock is %d\n\r",timeError);

	timeError_i = timeError;

	if(timeError > 1000)
	{
		errtooPos = true;
		//xil_printf("ErrtooPos\n\r");
	}
	else if (timeError < -1000)
	{
		errtooNeg = true;
		//xil_printf("ErrtooNeg\n\r");
	}
	else
	{
		if(errtooPos == true && timeError < 50)
		{
			errtooPos = false;
			u8 i;
			for (i = 0; i < 3; i++) {
				in[i] = 0;
				out[i] = (float)(tunedDacvalue + 0x50);
				timeError_i = 40;
			}
			//xil_printf("ErrtooPos: Filter reinitialized");
		}
		else if(errtooNeg ==true && timeError > -50)
		{
			errtooNeg = false;
			u8 i;
			for (i = 0; i < 3; i++) {
				in[i] = 0;
				out[i] = (float)(tunedDacvalue - 0x50);
				timeError_i = -40;
			}
			//xil_printf("ErrtooNeg: Filter reinitialized");

		}
	}

	// Sanity check.
	if ((timeError > TIME_ERROR_MAX) || (timeError < -TIME_ERROR_MAX)) {
		message.lastGnssPpsInvalid = true;
		xil_printf("Time error sanity check failed (%d).\n\r", timeError);

		return;
	}

	//adjust error to speed up stabilizing
	timeError_propotional = ((float)timeError_i);


	if(timeError_propotional < 2.0 && timeError_propotional >-2.0)
	{
		timeError_propotional=0;
	}
	else if(timeError_propotional > 50.0 || timeError_propotional <-50.0)
	{
		//timeError_propotional = ((float)timeError_propotional);

	}
	else
	{
		timeError_propotional = timeError_propotional*1.5f;
	}



	// Loop filter
	float tcxoDacSmoothed = filter_iir(timeError_propotional);
	//float tcxoDacSmoothed = filter_iir(((float)timeError)); //old

	// Get new DAC value
	newDacValue = (s32)((tcxoDacSmoothed + 0.5f));  // Negative value will be capped in dac7611_write()

	// Write DAC value
	dac82002_write(newDacValue);

	// Set PPS present flag
	message.gnssPpsMissing = false;

	// Save last GNSS counter value
	gnssClkLast = gnssClkExp;

	// Update TCXO locked flag every TCXO_LOCKED_UPDATE_RATE seconds
	// Lock is detected when the output of the phase detector (time error) value
	// and its derivative (rate change) is lower than the defined range
	if (++tcxoLockCounterSec == TCXO_LOCKED_UPDATE_RATE) {
		message.ppsInvalid = (tcxoLockError > TCXO_LOCKED_MAX_ERROR) | (tcxoLockError < -TCXO_LOCKED_MAX_ERROR);
		if(!message.ppsInvalid)
		{
			tunedDacvalue = 0xFFFF & dac82002_axiRead(DAC82002_WRITE_DATA);
			xil_printf("Tuned DAC Value is 0x%08x\n\r", tunedDacvalue);

		}
		tcxoLockError = 0;
		tcxoLockCounterSec = 0;
	} else {
		tcxoLockError += timeError;
	}

	// Calculate last internal PPS error relative to last GNSS PPS in clock cycles (1 clock cycle = 10 ns)
	// Positive error means that the internal PPS is ahead of the GNSS PPS
	// Negative error means that the internal PPS is delayed compared to the GNSS PPS
	intClkMeas = timeCtrl_axiRead(TIME_CTRL_INT_PPS_CLK_COUNT);
	intPpsError = (s32)intClkMeas - (s32)gnssClkMeas;


	xil_printf("timestamp=%d, dacValue=%d, tcxoDacSmoothed=%d, timeError=%d, tcxoLockError=%d, ppsIntError=%d, ppsInvalid=%d\n\r",
		TIMECTRL_TIMESTAMP(), newDacValue, (int)(tcxoDacSmoothed * 1000), timeError, tcxoLockError, intPpsError, (int)message.ppsInvalid);

}

// Send time to UART for the rest of the system
// This function is run once per second (dependent on the internal PPS
// such that a GNSS PPS loss does not alter operation)
void timeCtrl_sendTimestamp() {

	// Do not transmit any time message
	// when the internal PPS output is disabled
	if (!TIMECTRL_GET_PPS_INT_ENABLE()) {
		return;
	}

	// Get time keeping from FPGA.
	// Running on internal PPS and free-running 50 MHz clock
	u32 currentclkSincePps = TIMECTRL_CLKS_SINCE_PPS();

	// Only process after some time to be sure tcxoAutoTuneUpdate()
	// has been done for the current PPS
	if (currentclkSincePps < CLK_50MHz_FREQUENCY_CLKS/4) {
		lastTimeMessageSent = false;
		return;
	}

	// Message already transmitted for this second?
	else if (lastTimeMessageSent) {
		return;
	}

	// Set time for this message
	message.time = TIMECTRL_TIMESTAMP();

	// Format UBX-DIG14-TIME message
	memcpy(messageData, &message, sizeof(ubxDig14TimeMessage_t));
	int ret = uUbxProtocolEncode(UBX_CLASS_DIG14, DIG14_TIME_ID,
			messageData, sizeof(ubxDig14TimeMessage_t), txBuffer);
	if (ret != UBX_DIG14_TIME_FRAME_LEN) {
		xil_printf("Error encoding UBX-DIG14-TIME message");
		return;
	}

#ifndef UBX_DIG14_TIME_IN_ASCCI_FORMAT
	// Send binary message on UART
	u8 i;
	//xil_printf("Send binary message on UART\n\r");
	for (i = 0; i < UBX_DIG14_TIME_FRAME_LEN; i++) {
		XUartNs550_SendByte(USB_UART_BASEADDR, (u8)txBuffer[i]);
	}

#else
	// Print in ASCII format
	xil_printf("timestamp=%d, clksSincePPS=%d, timeInvalid=%d, ppsInvalid=%d, gnssPpsMissing=%d, lastGnssPpsInvalid=%d\n\r",
		message.time, currentclkSincePps, (int)message.timeInvalid, (int)message.ppsInvalid, (int)message.gnssPpsMissing, (int)message.lastGnssPpsInvalid);
#endif

	lastTimeMessageSent = true;

	// Reset flags
	message.gnssPpsMissing = true;
	message.lastGnssPpsInvalid = false;
}

// Set/monitor time
void timeCtrl_setTime(u32 nextPpsTimestamp) {

    if (isTimeSet) {
		// Monitor timestamp in FPGA if the time has been set
    	// Get FPGA timestamp
    	u32 fpgaTimestamp = TIMECTRL_TIMESTAMP();
    	if ((fpgaTimestamp + 1) != nextPpsTimestamp) {
    		xil_printf("Error! FPGA timestamp (%d) not in sync with GNSS. Resyncing\n\r", fpgaTimestamp);
    		TIMECTRL_SET_NEXT_PPS_TIMESTAMP(nextPpsTimestamp);
    		message.timeInvalid = true;
    	} else {
    		xil_printf("Timestamp OK!\n\r");
    		message.timeInvalid = false;
    	}
    } else {
    	// Set timestamp in FPGA module
    	xil_printf("Setting timestamp in FPGA module\n\r");
    	TIMECTRL_SET_NEXT_PPS_TIMESTAMP(nextPpsTimestamp);
    	isTimeSet = true;
    }

}


//DAC82002 write function
static int dac82002_write(s32 value){

	s32 dacStatus = dac82002_axiRead(DAC82002_STATUS);

	if (dacStatus == 0) {
		//check dac limit and adjust
		if (value<DAC82002_MIN){
			value = DAC82002_MIN;
		}
		else if(value>DAC82002_MAX){
			value = DAC82002_MAX;
		}
		s32 prevDacValue = dac82002_axiRead(DAC82002_WRITE_DATA);

		//create dac_data with Vout A reg enabled
		s32 dacData= 0x00080000 + value; //0x00080000 is base for VOUT A

		if (dacData != prevDacValue ) {
			//set to DAC_WRITING STATUS
			dac82002_axiWrite(DAC82002_STATUS,0x00000001);
			//usleep(10000);


			dac82002_axiWrite(DAC82002_WRITE_DATA,dacData);
			usleep(10000);

			//set to DAC_IDLE STATUS
			dac82002_axiWrite(DAC82002_STATUS,0x00000000);
			//usleep(10000);

			return XST_SUCCESS;
		}
		else {
			return XST_SUCCESS; //no need to re-write
		}
	}
	else {
		//dac is busy
		return XST_FAILURE;
	}



}

// Filter new sample
static float filter_iir(float in_new) {

	int i;

	// Prepare for new sample
	for (i = 2; i > 0; i--) {
		out[i] = out[i-1];
		in[i] = in[i-1];
	}
	out[0] = 0.0f;
	in[0] = in_new;


	for (i = 0; i < 3; i++) {
		out[0] += b[i] * in[i];
	}
	for (i = 1; i < 3; i++) {
		out[0] -= a[i] * out[i];
	}

	//out[0] /= a[0];  // assume a[0] = 1

	return out[0];
}
