/*
 * ubx_messsage.h
 *
 *  Created on: Apr 4, 2022
 *      Author: ise
 */

#ifndef UBX_MESSAGE_H_
#define UBX_MESSAGE_H_

/*******************************************************************************
 * Include Files
 ******************************************************************************/

#include "stdint.h"

#include "u_ubx_protocol.h"

/*******************************************************************************
 * Constants
 ******************************************************************************/

/*******************************************************************************
 * Types
 ******************************************************************************/

enum UBX_CLASS_ID {
    UBX_CLASS_NAV = 0x01, /* Navigation Results Messages */
    UBX_CLASS_RXM = 0x02, /* Receiver Manager Messages */
    UBX_CLASS_INF = 0x04, /* Information Messages */
    UBX_CLASS_ACK = 0x05, /* Ack/Nack Messages */
    UBX_CLASS_CFG = 0x06, /* Configuration Input Messages */
    UBX_CLASS_UPD = 0x09, /* Firmware Update Messages */
    UBX_CLASS_MON = 0x0A, /* Monitoring Messages */
    UBX_CLASS_AID = 0x0B, /* AssistNow Aiding Messages */
    UBX_CLASS_TIM = 0x0D, /* Timing Messages */
    UBX_CLASS_ESF = 0x10, /* External Sensor Fusion Messages */
    UBX_CLASS_MGA = 0x13, /* Multiple GNSS Assistance Messages */
    UBX_CLASS_LOG = 0x21, /* Logging Messages */
    UBX_CLASS_SEC = 0x27, /* Security Feature Messages */
    UBX_CLASS_HNR = 0x28, /* High Rate Navigation Results Messages */
    UBX_CLASS_DIG14 = 0x30, /* Digital14 Messages*/
};

enum UBX_TIM_ID {
    UBX_TIM_DOSC = 0x11, /* Disciplined oscillator control */
    UBX_TIM_FCHG = 0x16, /* Oscillator frequency changed notification */
    UBX_TIM_HOC = 0x17, /* Host oscillator control */
    UBX_TIM_SMEAS = 0x13, /* Source measurement */
    UBX_TIM_SVIN = 0x04, /* Survey-in data */
    UBX_TIM_TM2 = 0x03, /* Time mark data */
    UBX_TIM_TOS = 0x12, /* Time pulse time and frequency data */
    UBX_TIM_TP = 0x01, /* Time pulse time data */
    UBX_TIM_VCOCAL = 0x15, /* VCO Calibration */
    UBX_TIM_VRFY = 0x06, /* Sourced time verification */
};

#define DIG14_TIME_ID 0x01

typedef struct {
    uint32_t towMS; /* Time pulse time of week according to time base */
    uint32_t towSubMS; /* Submillisecond part of towMS */
    int32_t qErr; /* Quantization error of time pulse */
    uint16_t week; /* Time pulse week number according to time base */
    union {
        u8 flags; /* Flags */
        struct {
            u8 timeBase    : 1; /* 0 = Time base is GNSS ,1 = Time base is UTC */
            u8 utc         : 1; /* 0 = UTC not available, 1 = UTC available */
            u8 raim        : 2; /* (T)RAIM information: 0 = Information not available, 1 = Not active, 2 = Active */
            u8 qErrInvalid : 1; /* 0 = Quantization error valid, 1 = Quantization error invalid */
            u8             : 3; /* Unused */
        };
    };
    union {
        u8 refInfo; /* Time reference information */
        struct {
            u8 timeRefGnss : 4; /* GNSS reference information. Only valid if time base is GNSS (timeBase=0).
                                    0 = GPS
                                    1 = GLONASS
                                    2 = BeiDou
                                    3 = Galileo
                                    4 = NavIC
                                    15 = Unknown */
            u8 utcStandard : 4; /* UTC standard identifier. Only valid if time base is UTC (timeBase=1).
                                    0 = Information not available
                                    1 = Communications Research Laboratory (CRL), Tokyo, Japan
                                    2 = National Institute of Standards and Technology (NIST)
                                    3 = U.S. Naval Observatory (USNO)
                                    4 = International Bureau of Weights and Measures (BIPM)
                                    5 = European laboratories
                                    6 = Former Soviet Union (SU)
                                    7 = National Time Service Center (NTSC), China
                                    8 = National Physics Laboratory India (NPLI)
                                    15 = Unknown */
        };
    };
} __attribute__ ((packed)) ubxTimTpMessage_t;

typedef struct {
	uint32_t time; /* PPS time in second */
    union {
        u8 flags; /* Flags */
        struct {
        	u8 timeInvalid 			: 1; /* Time field invalid */
        	u8 ppsInvalid  			: 1; /* PPS invalid */
        	u8 gnssPpsMissing		: 1; /* GNNS PPS missing */
        	u8 lastGnssPpsInvalid 	: 1; /* Last GNSS PPS invalid */
            u8             			: 5; /* Unused */
        };
    };
} __attribute__ ((packed)) ubxDig14TimeMessage_t;

// UBX-TIM-TP frame length in bytes
#define UBX_TIM_TP_FRAME_LEN 		(sizeof(ubxTimTpMessage_t) + U_UBX_PROTOCOL_OVERHEAD_LENGTH_BYTES)

// UBX-DIG14-TIME frame length in bytes
#define UBX_DIG14_TIME_FRAME_LEN 	(sizeof(ubxDig14TimeMessage_t) + U_UBX_PROTOCOL_OVERHEAD_LENGTH_BYTES)

/*******************************************************************************
 * Macros
 ******************************************************************************/

/*******************************************************************************
 * Function Prototypes
 ******************************************************************************/

#endif /* UBX_MESSAGE_H_ */
