/*******************************************************************************
 * MADUSHAN S.D. - THAKSHANA TECHNOLOGIES
 ******************************************************************************/

/*******************************************************************************
 * Include Files
 ******************************************************************************/
#include <xil_printf.h>
#include "xil_cache.h"
#include "xstatus.h"
#include "xuartns550_l.h"
#include "xgpio_l.h"

#include "gnss.h"
#include "sp7_hw.h"
#include "time_ctrl.h"
#include "sleep.h"

#include <stdio.h>
#include "xil_io.h"
#include "flash_upgrade.h"

/*******************************************************************************
 * Constants
 ******************************************************************************/
#define TS_APP_VERSION "1.0.0.sp7"
#define FU_APP_VERSION "1.0.0.sp7"
#define APP_VERSION "A.0.2.sp7"

#define EXT_OCXO 0
#define INT_CLK 1

//stateMachine
#define CLK_INIT           		 0
#define GPS_SYNCHRONIZATION		 1
#define FLASH_UPGRADE_SPI_INIT   2
#define FLASH_UPGRADE      		 3
#define FLASH_UPGRADE_WAIT 		 4
#define P_HALTS            		 5

#define ZU_LS_GPIO_ID XPAR_HIER_MICROBLAZE_AXI_GPIO_ZU_LS_MOD_DEVICE_ID

/*******************************************************************************
 * Types
 ******************************************************************************/

/*******************************************************************************
 * Macros
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
static int state = CLK_INIT;
/*******************************************************************************
 * Function Prototypes
 ******************************************************************************/
static void platform_halt();
static void init_uart();
int clk_detector_init();


// Halt software execution i.e it waits forever until the system is reset
static void platform_halt() {

	xil_printf("Platform halted\n\r");
	while(1) {}
}

// Initialize USB UART
static void init_uart()
{

	XUartNs550_SetBaud(USB_UART_BASEADDR, USB_UART_CLK_HZ, USB_UART_BAUD);
    XUartNs550_SetLineControlReg(USB_UART_BASEADDR, XUN_LCR_8_DATA_BITS);
}


// Main function for the Microblaze software.
int main()
{
	//gps
	int gps_status;
	int clk_select;
	int flash_start = 0;
	u32 stopwatch;
	u32 maxStopWatch = 0;

	//flash upgrade
	int Status;
	int SPI_Status;
	int blk_cnt;
	int blk_number;
	u32 Command;
	u32 WriteAddr;
	u32 EndAddr;
	u8 *DataPtr;


	//disableCache
	Xil_ICacheDisable();
	Xil_DCacheDisable();

	init_uart();
	//sleep(6);
	//Initialize to internal clock
	clk_select = INT_CLK;


	xil_printf("\n\r\n\r *** SP7 P3 Golden Application v%s ***\n\r\n\r",APP_VERSION);
	sleep(5);

	while(1)
	{
		switch(state){
		case CLK_INIT:
			if (clk_select != EXT_OCXO) {
				xil_printf("\n\rForced to internal clock. Fine Tuning Aborted \n\r");
				state = FLASH_UPGRADE_SPI_INIT;
				break;
				//return 0;
			}
			else {
				xil_printf("\n\rExternal OCXO detected.\n\n\r");
				state = GPS_SYNCHRONIZATION;
			}
			break;

		case GPS_SYNCHRONIZATION:
			xil_printf("\n\rSWITCHED TO: SP7 Time Control Application v%s\n\r\n\r", TS_APP_VERSION);
			//Initialize GNSS Module
			gps_status = gnss_init();
			if (gps_status != XST_SUCCESS) {
				xil_printf("Error: Failed to initialize GNSS module\n\r");

				state = FLASH_UPGRADE_SPI_INIT;
				break;
				//platform_halt();
			}
			else {
				xil_printf("Success: Initialized GNSS module\n\r");
			}

			//Initialize Time Control IP
			gps_status = timeCtrl_init();
			if (gps_status != XST_SUCCESS) {
				xil_printf("Error: Failed to initialize timeCtrl module\n\r");
				state = FLASH_UPGRADE_SPI_INIT;
				break;
				//platform_halt();
			}
			else {
				xil_printf("Success: Initialized timeCtrl module\n\r");
			}


			while (!clk_select && state!=FLASH_UPGRADE_SPI_INIT)
			{
				// Reset stopwatch
				TIMECTRL_RESET_STOPWATCH();

				// Process GNSS UART data
				gnss_uartProcess();

				// Update TCXO tuning loop
				timeCtrl_tcxoAutoTuneUpdate();

				// Forward time to the rest of the system via UART
				timeCtrl_sendTimestamp();

				// Monitor stopwatch
				stopwatch = TIMECTRL_READ_STOPWATCH();
				if (stopwatch > maxStopWatch)
				{
					maxStopWatch = stopwatch;
					xil_printf("New max main while() exec time: %d clk\n\r", maxStopWatch);
				}

				//external clock polling
				clk_select = XGpio_ReadReg(CLOCK_SELECT_ADDR,CLOCK_SELECT_SIG_OFFSET);
				if(clk_select != EXT_OCXO)
				{
					xil_printf("\n\rSwitched to Internal Clock. Fine Tuning Aborted \n\r");
					state = FLASH_UPGRADE_WAIT;
					break;
					   //return 0;
				}

				//flash upgrade polling
				flash_start = XGpio_ReadReg(FLASH_START_ADDR,FLASH_START_OFFSET);
				if(flash_start)
				{
					state = FLASH_UPGRADE_SPI_INIT;
					break;
				}
			}
			break;
		case FLASH_UPGRADE_SPI_INIT:
			Status = SpiInitialize();
			if (Status != XST_SUCCESS) {
				xil_printf("SPI Init failed!\n\r");
				state = P_HALTS;
				//return XST_FAILURE;
			}
			else
			{
				xil_printf("SPI Initialized...\n\r");
				state = FLASH_UPGRADE;
			}
			break;
		case FLASH_UPGRADE_WAIT:
			if(!SPI_Status)
			{
				SPI_Status = SpiInitialize();
				if (SPI_Status != XST_SUCCESS) {
					xil_printf("SPI Init failed!\n\r");
					state = P_HALTS;
					//return XST_FAILURE;
				}
				else
				{
					xil_printf("SPI Initialized...\n\r");
				}
			}

			//flash upgrade polling
			print("Waiting for flash start command from  NXP...");
			flash_start = XGpio_ReadReg(CLOCK_SELECT_ADDR,FLASH_START_OFFSET);
			usleep(500000);
			if(flash_start)
			{
				state = FLASH_UPGRADE_SPI_INIT;
			}
			break;
		case FLASH_UPGRADE:

			xil_printf("\n\rSWITCHED TO: SP7 Flash Upgrade Application v%s\n\r", FU_APP_VERSION);

			Status = XST_SUCCESS;
			// Loop to wait that NXP ask to start upgrade
			print("Wait command from  NXP!\n\r");
			do {
				sleep(1);
				Command = Xil_In32(BRAM_CTRL_REG+COMMAND_OFFSET);
				print(".");
			}while(Command == CMD_IDLE);

			print("\n\rGot start command!\n\r");

			Xil_Out32(BRAM_CTRL_REG+COMMAND_OFFSET, CMD_IDLE);
			Xil_Out32(BRAM_CTRL_REG+STATUS_OFFSET, STATUS_ONGOING);

			// Read Flashing address from BRAM which NXP writes
			WriteAddr = Xil_In32(BRAM_CTRL_REG+BRAM_WRITE_ADDR_OFFSET);
			EndAddr = WriteAddr + BS_SIZE_WIHT_HDR;
			printf("WriteAddr is 0x%lX, end address is 0x%lX.\n\r", WriteAddr, EndAddr);

			printf("Erase flash started!\n\r");
			if (SpiFlashErase(WriteAddr, BS_SIZE_WIHT_HDR)) {
				printf("Flash erase failed!\n\r");
				Xil_Out32(BRAM_CTRL_REG+STATUS_OFFSET, STATUS_ERROR);
				Status = XST_FAILURE;
				continue;
			}

			printf("Erase done!\n\r");

			Xil_Out32(BRAM_CTRL_REG+BRAM_VALID_OFFSET, WAIT_DATA);

			printf("Data write to flash started!\n\r");
			DataPtr = (u8 *)BRAM_DATA_REG;
			blk_cnt = 0;
			while (WriteAddr < EndAddr) {
				//Wait that NXP write that BRAM data is valid
				do {
					Command = Xil_In32(BRAM_CTRL_REG+BRAM_VALID_OFFSET);
				}while(Command != DATA_READY);

				blk_number = Xil_In32(BRAM_CTRL_REG+BLOCK_NUMBER_OFFSET);
				if (blk_number != blk_cnt) {
					printf("Block number doesn't match! Current block counter value %d, block number from NXP %d\n\r", blk_cnt, blk_number);
					Status = XST_FAILURE;
					break;
				}

				printf("Write address  0x%lX, block number %d, block counter %d.\n\r", WriteAddr, blk_number, blk_cnt);

				if (SpiFlashWrite(WriteAddr, DataPtr, BRAM_SIZE)) {
					printf("Flash write failed!\n\r");
					Status = XST_FAILURE;
					break;
				}
				Xil_Out32(BRAM_CTRL_REG+BRAM_VALID_OFFSET, WAIT_DATA);

				WriteAddr = WriteAddr + BRAM_SIZE;
				blk_cnt++;
			}

			Xil_Out32(BRAM_CTRL_REG+BRAM_VALID_OFFSET, IDLE);

			if (Status) {
				printf("Flash upgrade failed!\n\r");
				Xil_Out32(BRAM_CTRL_REG+STATUS_OFFSET, STATUS_ERROR);
			} else {
				printf("Flash upgrade done!\n\r");
				Xil_Out32(BRAM_CTRL_REG+STATUS_OFFSET, STATUS_DONE);
				//state = P_HALTS;
				//break;
			}
			sleep(2);
			Xil_Out32(BRAM_CTRL_REG+STATUS_OFFSET, IDLE);
			Xil_Out32(BRAM_CTRL_REG+COMMAND_OFFSET, CMD_IDLE);

			break;
		case P_HALTS:
			// do nothing
			platform_halt();
			break;
		default:
			state = P_HALTS;
			break;
		}
	}
    return 0;
}
