#define BRAM_SIZE					4096

#define BRAM_DATA_REG				0x00110000
#define BRAM_CTRL_REG				0x00100000

#define COMMAND_OFFSET				0x00
#define STATUS_OFFSET				0x04
#define BRAM_VALID_OFFSET			0x08
#define BRAM_WRITE_ADDR_OFFSET		0x0C
#define BLOCK_NUMBER_OFFSET			0x10

#define CMD_IDLE					0x00
#define CMD_START_FLASHING			0x01

#define STATUS_ONGOING				0x01
#define STATUS_DONE					0x02
#define STATUS_ERROR				0x03

#define IDLE						0x00
#define WAIT_DATA					0x01
#define DATA_READY					0x02
#define DATA_ONGOING				0x04

#define FLASH_PAGE_SIZE				256

#define BS_SIZE						1241804
#define BS_SIZE_WIHT_HDR			1241916


#define SECTOR_CNT_64KB				1024
#define SECTOR_SIZE_4KB				4096
#define SECTOR_SIZE_64KB			65536

int SpiInitialize();
int SpiFlashRead(u32 Addr,  u8 *data, u32 ByteCount);
int SpiFlashWrite(u32 Addr, u8 *data, u32 ByteCount);
int SpiFlashErase(u32 Addr, u32 ByteCount);
